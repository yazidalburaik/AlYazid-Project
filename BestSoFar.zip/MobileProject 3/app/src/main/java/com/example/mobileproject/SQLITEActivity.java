package com.example.mobileproject;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SQLITEActivity extends AppCompatActivity {


    EditText inp_f_name;
    EditText inp_l_name;
    EditText inp_phone;
    EditText inp_email;
    EditText inp_uid;

    Button btn_insert;
    Button btn_insert_from_firebase;
    Button btn_update;
    Button btn_select_options;
    Button btn_delete;

    FirebaseDatabase database;
    DatabaseReference ref;

    private void setup(){
        database = FirebaseDatabase.getInstance();
        ref = database.getReference("users");

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_q_l_i_t_e);
        setup();
        DBHelper dbHelper=new DBHelper(this);

        inp_f_name=findViewById(R.id.firstName_Sql);
        inp_l_name=findViewById(R.id.lastName_Sql);
        inp_phone=findViewById(R.id.Phone_Sql);
        inp_email=findViewById(R.id.Email_Sql);
        inp_uid=findViewById(R.id.ID_Sql);

        btn_insert=findViewById(R.id.bttn_insertSQL);
        btn_insert_from_firebase=findViewById(R.id.bttn_insertFBSQL);
        btn_update=findViewById(R.id.bttn_updateSQL);
        btn_select_options=findViewById(R.id.bttn_SelectSQL);
        btn_delete=findViewById(R.id.bttn_deleteSQL);

        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fname=inp_f_name.getText()+"";
                String lname=inp_l_name.getText()+"";
                String phone=inp_phone.getText()+"";
                String email=inp_email.getText()+"";
                String uid=inp_uid.getText()+"";

                if (
                        fname.isEmpty() ||
                                lname.isEmpty() ||
                                phone.isEmpty() ||
                                email.isEmpty() ||
                                uid.isEmpty()){
                    Toast.makeText(SQLITEActivity.this,"Please fill in all fields for this operation",Toast.LENGTH_SHORT).show();
                }

                int i=dbHelper.insert(fname,lname,phone,email,Integer.valueOf(uid));
                if (i!=-1){
                    Toast.makeText(SQLITEActivity.this,"Record inserted",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(SQLITEActivity.this,"Record was not inserted.",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_insert_from_firebase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid=inp_uid.getText()+"";
                if (uid.isEmpty() ){
                    Toast.makeText(SQLITEActivity.this,"Please fill in UID field for this operation",Toast.LENGTH_SHORT).show();
                    return;
                }
                ref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for (DataSnapshot childData:snapshot.getChildren()){
                            if (childData.child("userId").getValue(Integer.class)==Integer.valueOf(uid)){
                                User u=snapshot.child(childData.getKey()).getValue(User.class);
                                int i=dbHelper.insert(u);

                                if (i!=-1){
                                    Toast.makeText(SQLITEActivity.this,"Record inserted",Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(SQLITEActivity.this,"Record was not inserted.",Toast.LENGTH_SHORT).show();
                                }
                                return;
                            }
                        }
                        Toast.makeText(SQLITEActivity.this,"No user with this UID was found",Toast.LENGTH_SHORT).show();
                        return;

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fname=inp_f_name.getText()+"";
                String lname=inp_l_name.getText()+"";
                String phone=inp_phone.getText()+"";
                String email=inp_email.getText()+"";
                String uid=inp_uid.getText()+"";

                if (
                        fname.isEmpty() ||
                                lname.isEmpty() ||
                                phone.isEmpty() ||
                                email.isEmpty() ||
                                uid.isEmpty()){
                    Toast.makeText(SQLITEActivity.this,"Please fill in all fields for this operation",Toast.LENGTH_SHORT).show();
                    return;
                }
                int i=dbHelper.updateUser(fname,lname,phone,email,Integer.valueOf(uid));
                if (i>0){
                    Toast.makeText(SQLITEActivity.this,"Record updated",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(SQLITEActivity.this,"No records were updated",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btn_select_options.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SQLITEActivity.this,SQLSelect.class));
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid=inp_uid.getText()+"";
                if (uid.isEmpty() ){
                    Toast.makeText(SQLITEActivity.this,"Please fill in uid field for this operation",Toast.LENGTH_SHORT).show();
                    return;
                }
                int i=dbHelper.deleteByUID(Integer.valueOf(uid));
                if (i>0){
                    Toast.makeText(SQLITEActivity.this,"Record deleted",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(SQLITEActivity.this,"No record was deleted",Toast.LENGTH_SHORT).show();

                }
            }
        });




    }
}